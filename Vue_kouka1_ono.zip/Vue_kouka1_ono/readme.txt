Vue_kouka1_kayanoフォルダのkayanoを自分の苗字に変更して
zipファイルで提出してください。

ソースでの確認も行いますので、実装したhtmlファイルも全て提出してください。

提出先：ooi_it2@stu.o-hara.ac.jp